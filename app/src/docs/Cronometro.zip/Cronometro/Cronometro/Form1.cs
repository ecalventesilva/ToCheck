﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Cronometro
{
    public partial class Form1 : Form
    {
        int contadorMinutos;
        int contadorSegundos;
        int contadorMilisegundos;

        public Form1()
        {
            InitializeComponent();
            this.Text = "Cronometro";
            button2.Enabled = false;
            button3.Enabled = false;
          
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            timer1.Interval = 1;
            timer1.Start();
            

            button1.Enabled = false;
            button3.Enabled = true;
        }


       
            


        private void timer1_Tick_1(object sender, EventArgs e)
        {
            contadorMilisegundos++;
            label3.Text = "Milisegundos: " + contadorMilisegundos;
            if (contadorMilisegundos > 100)
            {
                contadorMilisegundos = 0;
                contadorSegundos++;
                label2.Text = "Segundos: " + contadorSegundos;
            }
            if (contadorSegundos > 60)
            {
                contadorSegundos = 0;
                contadorMinutos++;
                label2.Text = "Minutos: " + contadorMinutos;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            contadorMilisegundos = 0;
            contadorSegundos = 0;
            contadorMinutos = 0;
            label3.Text = "Milisegundos: " + contadorMilisegundos;
            label2.Text = "Segundos: " + contadorSegundos;
            label1.Text = "Minutos: " + contadorMinutos;
            label4.Text = contadorMinutos + " : " + contadorSegundos + " : " + contadorMilisegundos;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            label4.Text = contadorMinutos + " : " + contadorSegundos + " : " + contadorMilisegundos;
            timer1.Stop();
            contadorMilisegundos = 0;
            contadorSegundos = 0;
            contadorMinutos = 0;
            label3.Text = "Milisegundos: " + contadorMilisegundos;
            label2.Text = "Segundos: " + contadorSegundos;
            label1.Text = "Minutos: " + contadorMinutos;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = false;
        

    }
    }
}
